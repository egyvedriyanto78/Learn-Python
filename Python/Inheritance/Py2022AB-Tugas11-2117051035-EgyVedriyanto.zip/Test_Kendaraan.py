from Kendaraan import Kendaraan
from Mobil import Mobil
from Motor import Motor

key = Kendaraan("","","")
key.printK()

mobil = Mobil("Innova Reborn",6, 2021,10)
mobil.printMobil()

motor = Motor("Vario", 3, 2019,"MotoCross")
motor.printMotor()

