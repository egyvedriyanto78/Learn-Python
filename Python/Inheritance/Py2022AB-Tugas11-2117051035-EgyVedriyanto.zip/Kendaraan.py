class Kendaraan:
    roda = 0
    
    def __init__ (self, merk, roda, tahun):
        self.merk = merk
        self.roda = roda
        self.tahun = tahun
        
    def printK(ok):
        print("--Data Inheritance Kendaraan--",ok.merk,ok.roda,ok.tahun)
        